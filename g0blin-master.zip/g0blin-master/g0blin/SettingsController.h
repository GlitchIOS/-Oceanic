//
//  SettingsController.h
//  g0blin
//
//  Created by Sticktron on 2017-12-30.
//  Copyright © 2017 Sticktron. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsController : UIViewController

@property (weak, nonatomic) IBOutlet UISwitch *reinstallBootstrapSwitch;

@end
